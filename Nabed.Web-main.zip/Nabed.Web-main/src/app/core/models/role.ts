export enum Role {
  All = 'All',
  Admin = 'Admin',
  Teacher = 'Teacher',
  Student = 'Student',
}
